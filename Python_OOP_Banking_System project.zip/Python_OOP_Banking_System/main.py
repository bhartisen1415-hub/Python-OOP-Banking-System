from datetime import datetime
from decimal import Decimal, InvalidOperation


class Transaction:
    """Represents a single deposit or withdrawal."""

    def __init__(self, transaction_type: str, amount: Decimal, balance_after: Decimal):
        self.timestamp = datetime.now()
        self.transaction_type = transaction_type
        self.amount = amount
        self.balance_after = balance_after

    def __str__(self) -> str:
        return (
            f"{self.timestamp:%Y-%m-%d %H:%M:%S} | "
            f"{self.transaction_type:<10} | Amount: ₹{self.amount:.2f} | "
            f"Balance: ₹{self.balance_after:.2f}"
        )


class Account:
    """Base bank account. Keeps balance private and validates transactions."""

    def __init__(self, account_holder: str, opening_balance=Decimal("0.00")):
        if not account_holder.strip():
            raise ValueError("Account holder name cannot be empty.")

        opening_balance = self._to_decimal(opening_balance)
        if opening_balance < 0:
            raise ValueError("Opening balance cannot be negative.")

        self.account_holder = account_holder.strip()
        self._balance = opening_balance
        self._transactions = []
        if opening_balance > 0:
            self._transactions.append(
                Transaction("OPENING", opening_balance, self._balance)
            )

    @staticmethod
    def _to_decimal(amount) -> Decimal:
        try:
            value = Decimal(str(amount)).quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError):
            raise ValueError("Enter a valid amount.") from None
        if not value.is_finite():
            raise ValueError("Enter a valid amount.")
        return value

    @property
    def balance(self) -> Decimal:
        """Read-only view of the current balance."""
        return self._balance

    def deposit(self, amount) -> None:
        amount = self._to_decimal(amount)
        if amount <= 0:
            raise ValueError("Deposit amount must be greater than zero.")
        self._balance += amount
        self._transactions.append(Transaction("DEPOSIT", amount, self._balance))

    def withdraw(self, amount) -> None:
        amount = self._to_decimal(amount)
        if amount <= 0:
            raise ValueError("Withdrawal amount must be greater than zero.")
        if amount > self._balance:
            raise ValueError("Insufficient balance.")
        self._balance -= amount
        self._transactions.append(Transaction("WITHDRAW", amount, self._balance))

    def transaction_history(self):
        return tuple(self._transactions)

    def account_type(self) -> str:
        """Polymorphic method overridden by child account classes."""
        return "General Account"


class SavingsAccount(Account):
    """Savings account with a minimum balance requirement."""

    def __init__(self, account_holder: str, opening_balance=Decimal("0.00"),
                 minimum_balance=Decimal("500.00")):
        self.minimum_balance = self._to_decimal(minimum_balance)
        opening_balance = self._to_decimal(opening_balance)
        if opening_balance < self.minimum_balance:
            raise ValueError(
                f"Savings account requires at least ₹{self.minimum_balance:.2f} "
                "as opening balance."
            )
        super().__init__(account_holder, opening_balance)

    def withdraw(self, amount) -> None:
        amount = self._to_decimal(amount)
        if amount <= 0:
            raise ValueError("Withdrawal amount must be greater than zero.")
        if self.balance - amount < self.minimum_balance:
            raise ValueError(
                f"Withdrawal denied. Maintain a minimum balance of "
                f"₹{self.minimum_balance:.2f}."
            )
        super().withdraw(amount)

    def account_type(self) -> str:
        return "Savings Account"


class CurrentAccount(Account):
    """Current account that uses the standard balance rules."""

    def account_type(self) -> str:
        return "Current Account"


class Bank:
    """Manages account creation and account lookup."""

    def __init__(self, name: str):
        self.name = name
        self._accounts = {}
        self._next_account_number = 1001

    def create_account(self, account_holder: str, account_kind: str,
                       opening_balance=Decimal("0.00")) -> Account:
        kind = account_kind.strip().lower()
        if kind == "savings":
            account = SavingsAccount(account_holder, opening_balance)
        elif kind == "current":
            account = CurrentAccount(account_holder, opening_balance)
        else:
            raise ValueError("Account type must be 'savings' or 'current'.")

        account_number = str(self._next_account_number)
        self._next_account_number += 1
        self._accounts[account_number] = account
        # Account number is assigned by the bank, not supplied by the user.
        account.account_number = account_number
        return account

    def get_account(self, account_number: str) -> Account:
        try:
            return self._accounts[str(account_number).strip()]
        except KeyError:
            raise ValueError("Account not found.") from None

    def list_accounts(self):
        return tuple(self._accounts.items())


def read_amount(prompt: str) -> Decimal:
    return Account._to_decimal(input(prompt).strip())


def main():
    bank = Bank("Python OOP Bank")
    print(f"Welcome to {bank.name}!")

    while True:
        print("\n1. Create account\n2. Deposit\n3. Withdraw\n"
              "4. Check balance\n5. Transaction history\n6. List accounts\n7. Exit")
        choice = input("Choose an option: ").strip()

        try:
            if choice == "1":
                name = input("Account holder name: ").strip()
                kind = input("Account type (savings/current): ").strip()
                opening = read_amount("Opening balance (₹): ")
                account = bank.create_account(name, kind, opening)
                print(f"Account created! Account number: {account.account_number}")
                print(f"Type: {account.account_type()} | Balance: ₹{account.balance:.2f}")

            elif choice in {"2", "3", "4", "5"}:
                number = input("Account number: ").strip()
                account = bank.get_account(number)

                if choice == "2":
                    account.deposit(read_amount("Deposit amount (₹): "))
                    print(f"Deposit successful. New balance: ₹{account.balance:.2f}")
                elif choice == "3":
                    account.withdraw(read_amount("Withdrawal amount (₹): "))
                    print(f"Withdrawal successful. New balance: ₹{account.balance:.2f}")
                elif choice == "4":
                    print(f"{account.account_holder} | {account.account_type()} "
                          f"| Balance: ₹{account.balance:.2f}")
                else:
                    history = account.transaction_history()
                    if not history:
                        print("No transactions yet.")
                    else:
                        print("\n--- Transaction History ---")
                        for transaction in history:
                            print(transaction)

            elif choice == "6":
                accounts = bank.list_accounts()
                if not accounts:
                    print("No accounts have been created yet.")
                else:
                    for number, account in accounts:
                        print(f"{number} | {account.account_holder} | "
                              f"{account.account_type()} | ₹{account.balance:.2f}")

            elif choice == "7":
                print("Thank you for using Python OOP Bank. Goodbye!")
                break
            else:
                print("Invalid option. Please choose 1-7.")

        except ValueError as error:
            print(f"Error: {error}")


if __name__ == "__main__":
    main()
