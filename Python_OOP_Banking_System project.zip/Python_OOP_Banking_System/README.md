# Python OOP Banking System

A beginner-friendly command-line banking application built with Object-Oriented Programming in Python.

## Features
- Create Savings and Current accounts
- Automatically assign account numbers
- Deposit money and withdraw money
- Check account balance
- View transaction history with timestamps
- List all accounts
- Input validation and helpful error messages
- Savings accounts maintain a minimum balance of ₹500

## OOP concepts demonstrated
- **Classes and objects:** `Bank`, `Account`, `SavingsAccount`, `CurrentAccount`, `Transaction`
- **Constructors:** `__init__()` initializes objects
- **Encapsulation:** account balance and account collections use `_balance`, `_transactions`, and `_accounts`; balance is exposed through a read-only property
- **Inheritance:** `SavingsAccount` and `CurrentAccount` inherit from `Account`
- **Polymorphism:** account classes provide their own `account_type()` implementation; `SavingsAccount` also overrides `withdraw()`
- **Abstraction:** the `Account` interface provides common operations while hiding transaction validation and recording details
- **Clean code:** focused classes, descriptive names, validation, and separation of responsibilities

## Requirements
- Python 3.10 or newer
- No third-party packages required

## Run the project
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

```bash
python main.py
```

On some systems, use `python3 main.py`.

## Example workflow
1. Select `1` to create a Savings account.
2. Enter a name, choose `savings`, and enter an opening balance of at least `500`.
3. Use the generated account number for deposits, withdrawals, balance checks, and transaction history.
4. Select `7` to exit.

## Class diagram

```mermaid
classDiagram
    class Bank {
      -dict _accounts
      -int _next_account_number
      +create_account(name, type, opening_balance) Account
      +get_account(account_number) Account
      +list_accounts()
    }

    class Account {
      +str account_holder
      -Decimal _balance
      -list _transactions
      +deposit(amount)
      +withdraw(amount)
      +transaction_history()
      +account_type() str
    }

    class SavingsAccount {
      +Decimal minimum_balance
      +withdraw(amount)
      +account_type() str
    }

    class CurrentAccount {
      +account_type() str
    }

    class Transaction {
      +datetime timestamp
      +str transaction_type
      +Decimal amount
      +Decimal balance_after
    }

    Account <|-- SavingsAccount
    Account <|-- CurrentAccount
    Bank o-- Account
    Account o-- Transaction
```

## Design notes
- `Bank` creates and finds accounts.
- `Account` contains shared banking behavior.
- `SavingsAccount` adds a minimum-balance rule.
- `CurrentAccount` uses the standard balance rules.
- `Transaction` records the type, amount, time, and balance after each operation.

## Important note
This is an educational project, not production banking software. It stores data in memory, so accounts and transactions are cleared when the program exits. It does not connect to real bank accounts or process real payments.

## Future improvements
- Save data to SQLite or a JSON file
- Add unit tests
- Add account login and authentication
- Add transfer between accounts
- Build a graphical user interface or web API
