# Project Documentation: Python OOP Banking System

## 1. Objective
Build a menu-driven banking simulation that demonstrates core Object-Oriented Programming concepts using Python.

## 2. Functional requirements
1. Create a savings or current account.
2. Generate a unique account number.
3. Deposit a positive amount.
4. Withdraw a positive amount when allowed by the account rules.
5. Display the current balance.
6. Show transaction history.
7. List all created accounts.

## 3. Architecture
The application uses four main layers of responsibility:
- **Bank:** account creation, numbering, lookup, and listing.
- **Account hierarchy:** shared balance and transaction operations.
- **Transaction:** stores transaction metadata.
- **CLI (`main()`):** collects user input and displays results.

## 4. Validation and business rules
- Account holder name cannot be blank.
- Opening balance cannot be negative.
- Savings account opening balance must be at least ₹500.
- Deposit and withdrawal amounts must be greater than zero.
- A withdrawal cannot exceed the available balance.
- A savings withdrawal must leave at least ₹500 in the account.
- Invalid account numbers and account types show clear errors.

## 5. OOP mapping
| Concept | Implementation |
|---|---|
| Class | `Account`, `Bank`, `Transaction` |
| Object | Each created bank account and transaction |
| Constructor | `__init__()` methods |
| Encapsulation | `_balance`, `_transactions`, `_accounts`; read-only `balance` property |
| Inheritance | `SavingsAccount(Account)`, `CurrentAccount(Account)` |
| Polymorphism | Overridden `account_type()` and `SavingsAccount.withdraw()` |
| Abstraction | Shared account operations hide validation and transaction recording details |

## 6. Limitations
Data is held in memory and disappears when the program exits. This is a learning prototype, not a real financial service.

## 7. Testing checklist
- [ ] Create a savings account with ₹500 or more.
- [ ] Try creating a savings account with less than ₹500 and confirm validation.
- [ ] Deposit ₹100 and verify the balance increases.
- [ ] Withdraw a valid amount and verify the balance decreases.
- [ ] Try withdrawing more than the balance.
- [ ] Try a savings withdrawal that would take the balance below ₹500.
- [ ] View transaction history.
- [ ] Enter an invalid account number.
